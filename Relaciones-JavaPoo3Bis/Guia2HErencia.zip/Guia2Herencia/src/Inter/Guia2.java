package Inter;

/**
 *
 * @author nickl
 */
public class Guia2 implements Guia22 {

    @Override
    public int metodo() {

        int suma = 2 + 5 + 2;
        
        System.out.println(suma);
        
        return suma;

    }

}
