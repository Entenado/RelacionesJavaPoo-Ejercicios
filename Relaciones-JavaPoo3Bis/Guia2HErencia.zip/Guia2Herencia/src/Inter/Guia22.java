package Inter;

/**
 *
 * @author nickl
 */
public interface Guia22 {

    public int metodo();

}
