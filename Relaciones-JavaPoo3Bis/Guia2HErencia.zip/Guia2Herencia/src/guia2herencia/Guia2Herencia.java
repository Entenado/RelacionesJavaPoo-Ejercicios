package guia2herencia;

import Inter.Guia2;

/**
 *
 * @author nickl
 */
public class Guia2Herencia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Guia2 g = new Guia2();

        g.metodo();

    }

}
