/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servicio;

import entidad.perro;
import entidad.persona;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class ser {
    List<persona> per = new ArrayList();
    Scanner entrada = new Scanner(System.in).useDelimiter("\n");
    ArrayList<perro> per3;
    perro d;
    persona aux2;
    public ser() {
        this.per3 = new ArrayList();
    }

    public void mascotas(){
        System.out.println("NOMBRE: ");
        String nombres = entrada.next();
        System.out.println("RAZA: ");
        String raza = entrada.next();
        System.out.println("EDAD: ");
        int edad = entrada.nextInt();
        System.out.println("TAMAÑO: ");
        String tamaño = entrada.next();
        d = new perro(nombres, raza, edad, tamaño);
        per3.add(d);        
    }

    public void usuario() {
        aux2 = new persona();
        System.out.println("ingrese su nombre ");
        String nombre = entrada.next();
        System.out.println("ingrese su apellido ");
        String apellido = entrada.next();
        System.out.println("ingrese su documento ");
        int docu = entrada.nextInt();
        System.out.println("ingrese su edad");
        int edad = entrada.nextInt();
        aux2 = new persona(nombre, apellido, edad, docu);
        per.add(aux2);
    }

    public void asignacion(){
        for (persona perr : per) {
            System.out.println(perr.getNombre() + ": quiere adoptar un perro las mascotas son; ");
            mostrarMascota();
            System.out.println("Que perro va a adoptar elija numero: ");
            int op = entrada.nextInt();                                
            if ((!per3.get(op).isAdoptado())) {
                perr.adoptarPerro(per3.get(op));                
            } else {
                System.out.println("Perro ya adoptado");
            }
        }
    }

    public void mostrarPersona() {
        System.out.println(per);
    }

    public void mostrarMascota() {
        System.out.println(per3);
    }
}
