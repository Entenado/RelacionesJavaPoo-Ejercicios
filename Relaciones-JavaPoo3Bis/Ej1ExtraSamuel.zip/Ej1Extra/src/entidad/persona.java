/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidad;

/**
 *
 * @author Samuel
 */
public class persona {
    private String nombre;
    private String apellido;
    private int edad;
    private int documento;
    private perro perros;

    public persona(String nombre, String apellido, int edad, int documento) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.documento = documento;
        this.perros = perros=null;
    }

    public persona() {
    }
    
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getDocumento() {
        return documento;
    }

    public void setDocumento(int documento) {
        this.documento = documento;
    }

    public perro getPerros() {
        return perros;
    }

    public void setPerros(perro perros) {
        this.perros = perros;
    }
    
    public void adoptarPerro(perro perros){
        this.perros = perros;
        perros.setAdoptado(true);
    }

    @Override
    public String toString() {
        return "persona:" + "nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + ", documento=" + documento + ", perros=" + perros + "\n";
    }
    
    
}
