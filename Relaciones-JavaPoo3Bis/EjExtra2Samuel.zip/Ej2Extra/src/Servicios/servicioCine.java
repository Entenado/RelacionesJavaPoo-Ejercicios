/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicios;

import Entidada.Cine;
import Entidada.Espectador;
import Entidada.Pelicula;
import Entidada.Sala;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class servicioCine {

    Scanner valor = new Scanner(System.in).useDelimiter("\n");
    double precio;
    serviciosPelicula pel = new serviciosPelicula();
    Pelicula pelicula = new Pelicula();
    Sala sala = new Sala();
    Cine cine = new Cine();
    char[][] salas = new char[9][7];

    public Cine crearCine() {
        pelicula = pel.crearPelicula();
        sala = crearSala();
        System.out.println("Ingrese el precio de la entrada: ");
        precio = valor.nextDouble();
        cine = new Cine(pelicula, sala, precio);
        return cine;
    }

    public Sala crearSala() {
        char letra = 'A';
        for (int i = 1; i <= 8; i++) {
            for (int j = 1; j <= 6; j++) {
                salas[i][0] = letra;
                salas[0][j] = Integer.toString(j).charAt(0);
                salas[i][j] = ' ';
            }
            letra++;
        }
        sala.setSal(salas);
        return sala;

    }

    public void mostrarSala() {
        for (int i = 0; i <= 8; i++) {
            System.out.println(" ");
            for (int j = 0; j <= 6; j++) {
                System.out.print("     " + sala.getSal()[i][j] + " ");
            }
            System.out.println("");
        }
    }

    public void vender(Espectador espectador) {
        int fil;
        int col;
        if (espectador.getDinero() < precio || espectador.getEdad() < pelicula.getEdadMinima()) {
            System.out.println("La persona no puede ver la pelicula");
        } else {
            boolean bandera=false;
            do {
                fil = ((int) (Math.random() * 7)) + 1;
                col = ((int) (Math.random() * 5)) + 1;               
                System.out.println("Fila:" + fil);              
                System.out.println("col:" + col);
                if (salas[fil][col] == 'X') {
                    bandera=true;
                }else{
                    salas[fil][col] = 'X';
                    bandera=false;
                    sala.setSal(salas);
                    System.out.println("Asiento reservado");             
                    //System.out.println("Lugar invalido");
//                    fil = ((int) (Math.random() * 7))+1;
//                    col = ((int) (Math.random() * 5))+1;
//                    System.out.println("Fila in:" + fil);
//                    System.out.println();
//                    System.out.println("col in:" + col);
//                    salas[fil][col] = 'L';
//                    sala.setSal(salas);
//                    System.out.println("Asiento reservado por invalido"); 
//                }else{                      
//                    System.out.println("Fila:" + fil);
//                    System.out.println();
//                    System.out.println("col:" + col);
//                    salas[fil][col] = 'X';
//                    sala.setSal(salas);
//                    System.out.println("Asiento reservado");                    
              }
            } while(bandera);
        }
    }
}
