/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicios;

import Entidada.Pelicula;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class serviciosPelicula {
    Scanner valor = new Scanner(System.in).useDelimiter("\n");
    public Pelicula crearPelicula(){       
        String titulo,dire;
        Pelicula pel;
        int dur,edadMin;
        System.out.println("Ingrese titulo de la pelicula: ");
        titulo=valor.next();
        System.out.println("Ingrese director de la pelicula");
        dire=valor.next();
        System.out.println("Ingrese duracion de la pelicula en minutos: ");
        dur=valor.nextInt();
        System.out.println("Ingrese edad minima para ver la pelicula: ");
        edadMin=valor.nextInt();
        pel = new Pelicula(titulo,dire,dur,edadMin);        
        return pel;

    }
}
