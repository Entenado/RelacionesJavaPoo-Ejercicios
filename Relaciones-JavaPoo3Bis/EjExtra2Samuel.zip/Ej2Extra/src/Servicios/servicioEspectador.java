/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicios;

import Entidada.Espectador;
import java.util.Scanner;

/**
 *
 * @author Samuel
 */
public class servicioEspectador {

    Scanner valor = new Scanner(System.in).useDelimiter("\n");

    public Espectador crearEspectardor() {
        Espectador espectador;
        String nom;
        int edad;
        float dinero;
        System.out.println("Ingrese el nombre de la persona: ");
        nom=valor.next();
        System.out.println("Ingrese edad de la persona: ");
        edad=valor.nextInt();
        System.out.println("Ingrese el dinero de la persona: ");
        dinero=valor.nextFloat();
        espectador=new Espectador(nom,edad,dinero);
        return espectador;

    }
}
