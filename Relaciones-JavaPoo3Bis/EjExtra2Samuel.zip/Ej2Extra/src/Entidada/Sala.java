/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidada;

import java.util.Arrays;

/**
 *
 * @author Samuel
 */
public class Sala {
   
    private char[][] sal;

    public Sala(char[][] sal) {
        this.sal = sal;
    }

    public Sala() {
    }
    
    

    public char[][] getSal() {
        return sal;
    }

    public void setSal(char[][] sal) {
        this.sal = sal;
    }

   
    @Override
    public String toString() {
        return "Sala{" + "sal=" + Arrays.toString(sal) + '}';
    }

   
    
   
    

}
