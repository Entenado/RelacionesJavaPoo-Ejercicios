/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ej2extra;

import Entidada.Cine;
import Entidada.Espectador;
import Servicios.servicioCine;
import Servicios.servicioEspectador;
import Servicios.serviciosPelicula;

/**
 *
 * @author Samuel
 */
public class Ej2Extra {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        servicioCine aux = new servicioCine();
        servicioEspectador aux2 =new servicioEspectador();
        Espectador espectador = new Espectador();        
        aux.crearSala();
        aux.crearCine();        
        espectador = aux2.crearEspectardor();        
        aux.vender(espectador);
        aux.vender(espectador);
        aux.vender(espectador);
        aux.vender(espectador);
        aux.vender(espectador);
        aux.vender(espectador);
        aux.vender(espectador);        
        aux.mostrarSala();
    }
    
}
